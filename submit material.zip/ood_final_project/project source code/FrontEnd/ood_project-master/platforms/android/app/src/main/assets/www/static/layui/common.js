<script src="layui.js"/>

<script>
    layui.config(
    dir: '../js/'}
).use('index');
</script>
